import React from 'react';
import { Book, Laptop, Sofa, Dumbbell, Shirt, Music, Bike, MoreHorizontal } from 'lucide-react';

const categories = [
  { id: '1', name: 'Textbooks', icon: Book },
  { id: '2', name: 'Electronics', icon: Laptop },
  { id: '3', name: 'Furniture', icon: Sofa },
  { id: '4', name: 'Fitness', icon: Dumbbell },
  { id: '5', name: 'Clothing', icon: Shirt },
  { id: '6', name: 'Music', icon: Music },
  { id: '7', name: 'Transportation', icon: Bike },
  { id: '8', name: 'More', icon: MoreHorizontal },
];

export default function CategoryBar() {
  return (
    <div className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between space-x-8 py-4 overflow-x-auto scrollbar-hide">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                className="flex flex-col items-center min-w-[4rem] space-y-1 text-gray-600 hover:text-emerald-600 transition-colors"
              >
                <Icon className="h-6 w-6" />
                <span className="text-xs">{category.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}