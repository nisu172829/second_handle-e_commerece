import React from 'react';
import { ArrowRight } from 'lucide-react';
import ProductCard from './ProductCard';
import type { Product } from '../types';

const FEATURED_PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'MacBook Pro M1 (2021)',
    price: 1299,
    description: 'Like new condition, includes charger and original box. Perfect for programming and design work.',
    category: 'Electronics',
    condition: 'Like New',
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=1000',
    seller: {
      name: 'Alex Chen',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100',
      rating: 4.9
    },
    createdAt: '2024-03-15'
  },
  {
    id: '2',
    title: 'Calculus Textbook Bundle',
    price: 75,
    description: 'Complete calculus textbook set with solution manual. Minor highlighting in first chapters.',
    category: 'Books',
    condition: 'Good',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1000',
    seller: {
      name: 'Emma Wilson',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100',
      rating: 4.8
    },
    createdAt: '2024-03-14'
  },
  {
    id: '3',
    title: 'Modern Study Desk',
    price: 120,
    description: 'Spacious desk with built-in storage. Perfect for dorm rooms or apartments.',
    category: 'Furniture',
    condition: 'Like New',
    imageUrl: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&q=80&w=1000',
    seller: {
      name: 'Marcus Johnson',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100',
      rating: 4.7
    },
    createdAt: '2024-03-13'
  }
];

export default function FeaturedProducts() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900">Featured Items</h2>
        <button className="text-purple-600 hover:text-purple-700 font-medium flex items-center">
          View all
          <ArrowRight className="ml-1 h-5 w-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {FEATURED_PRODUCTS.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}