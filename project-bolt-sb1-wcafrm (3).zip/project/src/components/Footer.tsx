import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">About</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-purple-600">About Us</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">How It Works</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Testimonials</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Press</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Help Center</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Safety Center</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Community Guidelines</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Terms of Service</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-600 hover:text-purple-600">Cookie Policy</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Install App</h3>
            <p className="text-gray-600 mb-4">Get the CampusTrade mobile app for iOS and Android</p>
            <div className="space-y-2">
              <button className="w-full px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors">
                App Store
              </button>
              <button className="w-full px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors">
                Google Play
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t text-center">
          <p className="text-gray-600">© 2024 CampusTrade. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}