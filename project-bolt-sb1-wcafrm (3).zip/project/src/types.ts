export interface Product {
  id: string;
  title: string;
  price: number;
  description: string;
  category: string;
  condition: 'New' | 'Like New' | 'Good' | 'Fair';
  imageUrl: string;
  seller: {
    name: string;
    avatar: string;
    rating: number;
  };
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}